#!/bin/sh

# This is where active development occurs
#
hg clone https://hg.mozilla.org/projects/htmlparser