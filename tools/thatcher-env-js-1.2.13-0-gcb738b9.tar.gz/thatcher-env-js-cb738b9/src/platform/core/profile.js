
/**
 *
 * @param {Object} options
 */
Envjs.profile = function(options){ throw new Error(this); };
