
/**
 * @todo: document
 */
var Window,
    Screen,
    History,
    Navigator;

