
//these are both non-standard globals that
//provide static namespaces and functions
//to support the html 5 parser from nu.
var XMLParser = {},
    HTMLParser = {};

    