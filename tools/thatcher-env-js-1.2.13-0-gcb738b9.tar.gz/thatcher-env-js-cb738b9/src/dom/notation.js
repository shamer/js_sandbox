/**
 * @author envjs team
 */
Notation = function() {
    throw new Error("Notation Not Implemented" );
};